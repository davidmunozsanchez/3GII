#ifndef COMPORTAMIENTOLIB
#define COMPORTAMIENTOLIB

#include "comportamientos/comportamiento.hpp"
//#include "comportamientos/objeto.hpp"
//#include "comportamientos/puerta.hpp"

#include "../Comportamientos_Jugador/jugador.hpp"
#include "../Comportamientos_Jugador/aldeano.hpp"
#include "../Comportamientos_Jugador/perro.hpp"

#endif
