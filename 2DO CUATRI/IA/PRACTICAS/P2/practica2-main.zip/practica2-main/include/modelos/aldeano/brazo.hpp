#ifndef BRAZOALDEANO3D_HPP
#define BRAZOALDEANO3D_HPP

#include "obj3dlib.hpp"
#include <string.h>


class BrazoAldeano3D : public Objeto3D{
private:

public:
  BrazoAldeano3D();
  ~BrazoAldeano3D();

};

#endif
