/*
 * Copyright (c) 2018, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.javafx.embed.swing.oldimpl;

import com.sun.javafx.embed.swing.FXDnDInterop;
import com.sun.javafx.embed.swing.InteropFactory;
import com.sun.javafx.embed.swing.JFXPanelInterop;
import com.sun.javafx.embed.swing.SwingFXUtilsImplInterop;
import com.sun.javafx.embed.swing.SwingNodeInterop;

public class InteropFactoryO extends InteropFactory {

    public InteropFactoryO() throws Exception {
        Class qeSwingClass = Class.forName("sun.swing.JLightweightFrame");
    }

    @Override
    public SwingNodeInterop createSwingNodeImpl() {
        return new SwingNodeInteropO();
    }

    @Override
    public JFXPanelInterop createJFXPanelImpl() {
        return new JFXPanelInteropO();
    }

    @Override
    public FXDnDInterop createFXDnDImpl() {
        return new FXDnDInteropO();
    }

    @Override
    public SwingFXUtilsImplInterop createSwingFXUtilsImpl() {
        return new SwingFXUtilsImplInteropO();
    }
}
